**Moved to https://github.com/firebase/user-data-protection/blob/master/doc/auto_rules_extraction.md**

