package auth0.com.socialloginsampleauth0;

public class Application extends android.app.Application {
    private static final String TAG = Application.class.getCanonicalName();

    public void onCreate() {
        super.onCreate();
    }
}

